# Pterodactyl Panel Contributors
This panel would not be possible without the support of our wonderful community of
developers who provide code enhancements, new features, and bug fixes to make this panel
the best that is can be. You can view a full listing of contributors [here](https://github.com/Pterodactyl/Panel/graphs/contributors).

Dane Everitt [@DaneEveritt](https://github.com/Pterodactyl/Panel/commits?author=DaneEveritt)

Dylan Seidt [@DDynamic](https://github.com/Pterodactyl/Panel/commits?author=DDynamic)

[@nikkiii](https://github.com/Pterodactyl/Panel/commits?author=nikkiii)

# Get Involved
See our `CONTRIBUTING.md` document for information on how to get started. Once you've submitted some code feel free to 
modify this file and add your name to the list. Please follow the format above for your name and linking to your contributions.
